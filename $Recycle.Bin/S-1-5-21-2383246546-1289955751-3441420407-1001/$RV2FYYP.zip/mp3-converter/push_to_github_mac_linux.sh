#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
read -rp "GitHub repo name [mp3-converter]: " REPO_NAME
REPO_NAME="${REPO_NAME:-mp3-converter}"

if ! command -v git >/dev/null 2>&1; then
  echo "Git was not found. Install Git first."
  exit 1
fi
if ! command -v gh >/dev/null 2>&1; then
  echo "GitHub CLI was not found. Install it from https://cli.github.com/ then run: gh auth login"
  exit 1
fi

[ -d .git ] || git init
git add .
git commit -m "Add MP3 converter app" || echo "Nothing new to commit."
gh repo create "$REPO_NAME" --public --source=. --remote=origin --push || {
  echo "Repo creation failed. Maybe it already exists. Trying normal push..."
  git branch -M main
  git push -u origin main
}
echo "Done. Open your repo on GitHub."

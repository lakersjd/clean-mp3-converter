"""Creates a 1-second WAV test tone and converts it to MP3. Useful for checking FFmpeg."""
from pathlib import Path
import math
import wave

from app import convert_file_to_mp3, OUTPUT_DIR

base = Path(__file__).resolve().parent
test_wav = base / "test_input.wav"
rate = 44100
with wave.open(str(test_wav), "w") as w:
    w.setnchannels(1)
    w.setsampwidth(2)
    w.setframerate(rate)
    frames = bytearray()
    for i in range(rate):
        sample = int(32767 * 0.25 * math.sin(2 * math.pi * 440 * i / rate))
        frames.extend(sample.to_bytes(2, "little", signed=True))
    w.writeframes(bytes(frames))

out = convert_file_to_mp3(test_wav, "test_input.wav", "192")
print(f"OK: created {out}")
print(f"Output folder: {OUTPUT_DIR}")

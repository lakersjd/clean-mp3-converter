from __future__ import annotations

import html
import ipaddress
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import time
import uuid
import webbrowser
from pathlib import Path
from urllib.parse import unquote, urlparse

import requests
from flask import Flask, flash, redirect, render_template, request, send_file, url_for
from werkzeug.utils import secure_filename

try:
    import imageio_ffmpeg
except Exception:
    imageio_ffmpeg = None

try:
    import yt_dlp
except Exception:
    yt_dlp = None

APP_VERSION = "3.0.0"
BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
OUTPUT_DIR = BASE_DIR / "converted"
LOG_DIR = BASE_DIR / "logs"
STARTUP_LOG = LOG_DIR / "startup.log"

MAX_UPLOAD_MB = int(os.environ.get("MAX_UPLOAD_MB", "500"))
MAX_URL_DOWNLOAD_MB = int(os.environ.get("MAX_URL_DOWNLOAD_MB", "500"))
MAX_DURATION_SECONDS = int(os.environ.get("MAX_DURATION_SECONDS", "7200"))
CONVERSION_TIMEOUT_SECONDS = int(os.environ.get("CONVERSION_TIMEOUT_SECONDS", "900"))
CLEANUP_AFTER_HOURS = int(os.environ.get("CLEANUP_AFTER_HOURS", "24"))

for folder in (UPLOAD_DIR, OUTPUT_DIR, LOG_DIR):
    folder.mkdir(exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "local-dev-change-me")
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_MB * 1024 * 1024

ALLOWED_INPUT_EXTENSIONS = {
    ".3gp", ".aac", ".aiff", ".amr", ".asf", ".avi", ".flac", ".m4a",
    ".m4v", ".mka", ".mkv", ".mov", ".mp3", ".mp4", ".mpeg", ".mpg",
    ".oga", ".ogg", ".opus", ".ts", ".wav", ".webm", ".wma", ".wmv",
}
BITRATES = {"128", "192", "256", "320"}
SAFE_URL_SCHEMES = {"http", "https"}
DIRECT_MEDIA_CONTENT_TYPES = (
    "audio/", "video/", "application/octet-stream", "binary/octet-stream",
    "application/x-mpegurl", "application/vnd.apple.mpegurl",
)
FILENAME_RE = re.compile(r"[^a-zA-Z0-9_.-]+")


class ConverterError(Exception):
    """User-friendly conversion failure."""


def write_startup_log() -> None:
    data = {
        "version": APP_VERSION,
        "python": sys.version.replace("\n", " "),
        "base_dir": str(BASE_DIR),
        "ffmpeg": ffmpeg_path_or_none(),
        "imageio_ffmpeg": bool(imageio_ffmpeg),
        "yt_dlp": bool(yt_dlp),
        "max_upload_mb": MAX_UPLOAD_MB,
        "max_url_mb": MAX_URL_DOWNLOAD_MB,
    }
    STARTUP_LOG.write_text(json.dumps(data, indent=2), encoding="utf-8")


def ffmpeg_path_or_none() -> str | None:
    system = shutil.which("ffmpeg")
    if system:
        return system
    if imageio_ffmpeg is not None:
        try:
            return imageio_ffmpeg.get_ffmpeg_exe()
        except Exception:
            return None
    return None


def ffmpeg_path() -> str:
    found = ffmpeg_path_or_none()
    if not found:
        raise ConverterError(
            "FFmpeg is missing. This version can auto-use imageio-ffmpeg, but the dependency is not installed. "
            "Run the launcher again, or run: python -m pip install -r requirements.txt"
        )
    return found


def clean_old_files(max_age_hours: int = CLEANUP_AFTER_HOURS) -> None:
    cutoff = time.time() - max_age_hours * 3600
    for folder in (UPLOAD_DIR, OUTPUT_DIR, LOG_DIR):
        for path in folder.iterdir():
            try:
                if path.is_file() and path.name != ".keep" and path.stat().st_mtime < cutoff:
                    path.unlink()
            except OSError:
                pass


def safe_stem(name: str | None) -> str:
    stem = Path(name or "converted").stem or "converted"
    stem = unquote(stem)
    stem = secure_filename(stem)
    stem = FILENAME_RE.sub("_", stem).strip("._-")
    return stem[:90] or "converted"


def safe_filename(name: str | None, default: str = "media") -> str:
    name = secure_filename(unquote(name or default)) or default
    if "." not in name:
        name += ".media"
    return name[:140]


def extension_is_allowed(filename: str) -> bool:
    return Path(filename).suffix.lower() in ALLOWED_INPUT_EXTENSIONS


def guessed_extension_from_url(url: str) -> str:
    suffix = Path(urlparse(url).path).suffix.lower()
    return suffix if suffix in ALLOWED_INPUT_EXTENSIONS else ".media"


def validate_public_url(url: str) -> None:
    parsed = urlparse(url)
    if parsed.scheme not in SAFE_URL_SCHEMES or not parsed.netloc:
        raise ConverterError("Paste a valid http:// or https:// link.")
    host = parsed.hostname
    if not host:
        raise ConverterError("That link does not include a valid host name.")

    # Block server-side requests to local/private networks. This matters if you deploy it publicly.
    try:
        for result in socket.getaddrinfo(host, None):
            ip = ipaddress.ip_address(result[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved:
                raise ConverterError("Local/private-network URLs are blocked. Upload the file instead.")
    except ConverterError:
        raise
    except Exception:
        # Let requests/yt-dlp surface DNS or network failures later.
        pass


def run_command(command: list[str], log_prefix: str, error_prefix: str) -> None:
    log_file = LOG_DIR / f"{log_prefix}_{uuid.uuid4().hex}.log"
    try:
        completed = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=CONVERSION_TIMEOUT_SECONDS,
        )
    except FileNotFoundError as exc:
        raise ConverterError(f"Missing executable: {command[0]}") from exc
    except subprocess.TimeoutExpired as exc:
        raise ConverterError("The conversion timed out. Try a smaller/shorter file.") from exc

    log_file.write_text((completed.stdout or "") + "\n" + (completed.stderr or ""), encoding="utf-8", errors="replace")
    if completed.returncode != 0:
        tail = (completed.stderr or completed.stdout or "")[-1800:].strip()
        raise ConverterError(f"{error_prefix}\n\nDetails from log:\n{tail or 'No details available.'}")


def convert_file_to_mp3(input_path: Path, display_name: str, bitrate: str) -> Path:
    if not input_path.exists() or input_path.stat().st_size == 0:
        raise ConverterError("The input file is empty or missing.")

    output_path = OUTPUT_DIR / f"{safe_stem(display_name)}_{uuid.uuid4().hex[:8]}.mp3"
    cmd = [
        ffmpeg_path(),
        "-hide_banner", "-y",
        "-i", str(input_path),
        "-vn",
        "-codec:a", "libmp3lame",
        "-b:a", f"{bitrate}k",
        "-map_metadata", "0",
        str(output_path),
    ]
    run_command(cmd, "ffmpeg", "FFmpeg could not convert that file. Try another media file or a lower bitrate.")
    if not output_path.exists() or output_path.stat().st_size == 0:
        raise ConverterError("The conversion finished but no MP3 was created.")
    return output_path


def download_direct_media_url(url: str) -> tuple[Path, str]:
    validate_public_url(url)
    ext = guessed_extension_from_url(url)
    parsed_name = Path(urlparse(url).path).name or f"downloaded_media{ext}"
    display_name = safe_filename(parsed_name, f"downloaded_media{ext}")
    target = UPLOAD_DIR / f"url_{uuid.uuid4().hex}{ext}"
    headers = {
        "User-Agent": "Mozilla/5.0 (compatible; LocalMP3Converter/3.0)",
        "Accept": "audio/*,video/*,application/octet-stream,*/*;q=0.8",
    }
    downloaded = 0
    try:
        with requests.get(url, stream=True, timeout=(15, 60), headers=headers, allow_redirects=True) as response:
            response.raise_for_status()
            length = response.headers.get("content-length")
            if length and int(length) > MAX_URL_DOWNLOAD_MB * 1024 * 1024:
                raise ConverterError(f"That file is larger than the {MAX_URL_DOWNLOAD_MB} MB URL limit.")

            content_type = response.headers.get("content-type", "").lower().split(";")[0].strip()
            if content_type and not content_type.startswith(DIRECT_MEDIA_CONTENT_TYPES) and ext == ".media":
                raise ConverterError(
                    "That looks like a webpage, not a direct media file. Use Platform Link mode for public platform pages."
                )

            with target.open("wb") as f:
                for chunk in response.iter_content(chunk_size=1024 * 1024):
                    if not chunk:
                        continue
                    downloaded += len(chunk)
                    if downloaded > MAX_URL_DOWNLOAD_MB * 1024 * 1024:
                        raise ConverterError(f"That file is larger than the {MAX_URL_DOWNLOAD_MB} MB URL limit.")
                    f.write(chunk)
    except ConverterError:
        target.unlink(missing_ok=True)
        raise
    except requests.RequestException as exc:
        target.unlink(missing_ok=True)
        raise ConverterError(f"Could not download that direct link: {exc}") from exc

    if not target.exists() or target.stat().st_size == 0:
        target.unlink(missing_ok=True)
        raise ConverterError("The link downloaded an empty file.")
    return target, display_name


def download_platform_to_mp3(url: str, bitrate: str) -> Path:
    validate_public_url(url)
    if yt_dlp is None:
        raise ConverterError("Platform Link mode needs yt-dlp. Run: python -m pip install -r requirements.txt")

    job_id = uuid.uuid4().hex[:10]
    outtmpl = str(OUTPUT_DIR / f"platform_{job_id}.%(ext)s")
    log_file = LOG_DIR / f"yt_dlp_{job_id}.log"

    ydl_opts = {
        "format": "bestaudio/best",
        "outtmpl": outtmpl,
        "noplaylist": True,
        "quiet": True,
        "no_warnings": False,
        "windowsfilenames": True,
        "restrictfilenames": True,
        "max_filesize": MAX_URL_DOWNLOAD_MB * 1024 * 1024,
        "socket_timeout": 45,
        "retries": 3,
        "fragment_retries": 3,
        "ffmpeg_location": str(ffmpeg_path()),
        "postprocessors": [{
            "key": "FFmpegExtractAudio",
            "preferredcodec": "mp3",
            "preferredquality": bitrate,
        }],
        # Intentionally no cookies, passwords, token extraction, or DRM bypassing.
    }

    try:
        with log_file.open("w", encoding="utf-8", errors="replace") as log:
            class Logger:
                def debug(self, msg):
                    log.write(str(msg) + "\n")
                    log.flush()
                def warning(self, msg):
                    log.write("WARNING: " + str(msg) + "\n")
                    log.flush()
                def error(self, msg):
                    log.write("ERROR: " + str(msg) + "\n")
                    log.flush()

            ydl_opts["logger"] = Logger()
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)
                duration = info.get("duration") if isinstance(info, dict) else None
                if duration and duration > MAX_DURATION_SECONDS:
                    raise ConverterError(f"That media is too long. Limit: {MAX_DURATION_SECONDS // 60} minutes.")
                ydl.download([url])
    except ConverterError:
        raise
    except Exception as exc:
        detail = str(exc).strip()
        log_tail = ""
        try:
            log_tail = log_file.read_text(encoding="utf-8", errors="replace")[-1800:]
        except Exception:
            pass
        raise ConverterError(
            "Platform Link mode could not download this link. It may be private, login-gated, DRM-protected, blocked by the site, or unsupported.\n\n"
            f"Details: {detail[-900:]}\n{log_tail}"
        ) from exc

    mp3s = sorted(OUTPUT_DIR.glob(f"platform_{job_id}*.mp3"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not mp3s:
        recent = [p for p in OUTPUT_DIR.glob("*.mp3") if time.time() - p.stat().st_mtime < 180]
        mp3s = sorted(recent, key=lambda p: p.stat().st_mtime, reverse=True)
    if not mp3s or mp3s[0].stat().st_size == 0:
        raise ConverterError("The platform download finished but no MP3 was created.")
    return mp3s[0]


def status_payload() -> dict[str, object]:
    ffmpeg = ffmpeg_path_or_none()
    return {
        "version": APP_VERSION,
        "ffmpeg": bool(ffmpeg),
        "ffmpeg_path": ffmpeg or "missing",
        "imageio_ffmpeg": imageio_ffmpeg is not None,
        "yt_dlp": yt_dlp is not None,
        "max_upload_mb": MAX_UPLOAD_MB,
        "max_url_mb": MAX_URL_DOWNLOAD_MB,
        "max_duration_minutes": MAX_DURATION_SECONDS // 60,
        "base_dir": str(BASE_DIR),
    }


@app.route("/", methods=["GET"])
def index():
    clean_old_files()
    return render_template("index.html", **status_payload())


@app.route("/convert", methods=["POST"])
def convert():
    bitrate = request.form.get("bitrate", "192")
    if bitrate not in BITRATES:
        bitrate = "192"
    mode = request.form.get("mode", "upload")
    input_path: Path | None = None

    try:
        if mode == "upload":
            uploaded = request.files.get("media_file")
            if not uploaded or not uploaded.filename:
                raise ConverterError("Choose a media file first.")
            if not extension_is_allowed(uploaded.filename):
                raise ConverterError("Unsupported file type. Try MP4, MOV, WEBM, WAV, FLAC, M4A, OGG, MP3, MKV, or AVI.")
            safe_name = safe_filename(uploaded.filename)
            input_path = UPLOAD_DIR / f"upload_{uuid.uuid4().hex}_{safe_name}"
            uploaded.save(input_path)
            output_path = convert_file_to_mp3(input_path, safe_name, bitrate)

        elif mode == "direct":
            media_url = (request.form.get("media_url") or "").strip()
            if not media_url:
                raise ConverterError("Paste a direct media file URL first.")
            input_path, display_name = download_direct_media_url(media_url)
            output_path = convert_file_to_mp3(input_path, display_name, bitrate)

        elif mode == "platform":
            if request.form.get("rights_confirm") != "yes":
                raise ConverterError("Check the permission box first.")
            media_url = (request.form.get("platform_url") or "").strip()
            if not media_url:
                raise ConverterError("Paste a public platform link first.")
            output_path = download_platform_to_mp3(media_url, bitrate)

        else:
            raise ConverterError("Pick Upload, Direct URL, or Platform Link mode.")

        return render_template("done.html", filename=output_path.name, size_mb=round(output_path.stat().st_size / 1024 / 1024, 2))

    except ConverterError as exc:
        return render_template("error.html", message=str(exc), status=status_payload()), 400
    except Exception as exc:
        return render_template("error.html", message=f"Unexpected error: {exc}", status=status_payload()), 500
    finally:
        if input_path and input_path.exists():
            try:
                input_path.unlink()
            except OSError:
                pass


@app.route("/download/<path:filename>")
def download(filename: str):
    safe_name = secure_filename(filename)
    path = OUTPUT_DIR / safe_name
    if not path.exists():
        return render_template("error.html", message="That converted file is gone. Convert it again.", status=status_payload()), 404
    return send_file(path, as_attachment=True, download_name=safe_name, mimetype="audio/mpeg")


@app.route("/health")
def health():
    payload = status_payload()
    return "<pre>" + html.escape(json.dumps(payload, indent=2)) + "</pre>"


@app.errorhandler(413)
def too_large(_error):
    return render_template("error.html", message=f"That upload is too large. Upload limit: {MAX_UPLOAD_MB} MB.", status=status_payload()), 413


if __name__ == "__main__":
    write_startup_log()
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "5000"))
    if os.environ.get("OPEN_BROWSER", "1") == "1":
        try:
            webbrowser.open(f"http://127.0.0.1:{port}")
        except Exception:
            pass
    app.run(host=host, port=port, debug=False)

# MP3 Converter

A Flask web app that converts media to MP3.

## Features

- Upload local audio/video files and convert them to MP3.
- Convert direct downloadable media URLs.
- Try public platform links with `yt-dlp` when the media is public and you own it or have permission to convert it.
- Choose MP3 quality: 128, 192, 256, or 320 kbps.
- Download the finished MP3 from the browser.
- Runs locally with Python or Docker.
- Includes GitHub Actions smoke tests and Docker build checks.

## Important limits

This app does **not** bypass DRM, paywalls, logins, private videos, cookies, region locks, or platform protections. It is for media you own or have permission to convert.

## Quick start on Windows

1. Download or clone this repository.
2. Double-click `start_windows.bat`.
3. Open `http://127.0.0.1:5000`.

The launcher creates a `.venv`, installs Python dependencies, and uses `imageio-ffmpeg` so you usually do not need to install FFmpeg manually.

## Quick start on Mac / Linux

```bash
./start_mac_linux.sh
```

## Docker

```bash
docker compose up --build
```

Open:

```text
http://127.0.0.1:5000
```

## Put this on GitHub

### Option A: GitHub CLI

Install GitHub CLI, then run:

```bash
gh auth login
./push_to_github_mac_linux.sh
```

On Windows, double-click:

```text
push_to_github_windows.bat
```

### Option B: Existing repo

```bash
git init
git add .
git commit -m "Add MP3 converter app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/mp3-converter.git
git push -u origin main
```

## Deploy from GitHub

The easiest backend-friendly deployment path is Docker. This repo includes:

- `Dockerfile`
- `docker-compose.yml`
- `render.yaml`
- `Procfile`
- `.github/workflows/test.yml`
- `.github/workflows/docker.yml`

For Render, create a new Web Service from the GitHub repo and choose the Docker runtime. Set `OPEN_BROWSER=0` and `HOST=0.0.0.0`.

## Test conversion

```bash
python run_test_conversion.py
```

It creates a tiny WAV file and converts it to MP3. If this works but a link fails, the problem is probably the link/site, not FFmpeg.

## Health check

Open:

```text
http://127.0.0.1:5000/health
```

## Logs

- Launcher log: `logs/launcher.log`
- Startup status: `logs/startup.log`
- Conversion logs: `logs/*.log`

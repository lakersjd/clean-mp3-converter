@echo off
setlocal
cd /d "%~dp0"

set /p REPO_NAME=GitHub repo name [mp3-converter]: 
if "%REPO_NAME%"=="" set REPO_NAME=mp3-converter

where git >nul 2>nul
if errorlevel 1 (
  echo Git was not found. Install Git from https://git-scm.com/downloads
  pause
  exit /b 1
)

where gh >nul 2>nul
if errorlevel 1 (
  echo GitHub CLI was not found. Install it from https://cli.github.com/
  echo Then run: gh auth login
  pause
  exit /b 1
)

if not exist .git git init
git add .
git commit -m "Add MP3 converter app" || echo Nothing new to commit.
gh repo create %REPO_NAME% --public --source=. --remote=origin --push
if errorlevel 1 (
  echo Repo creation failed. Maybe it already exists. Trying normal push...
  git branch -M main
  git push -u origin main
)

echo Done. Open your repo on GitHub.
pause

@echo off
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1
set OPEN_BROWSER=1

if exist logs\launcher.log del logs\launcher.log
if not exist logs mkdir logs

echo Starting MP3 Converter... > logs\launcher.log

where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found. Install Python 3.10+ from python.org, then run this again.
  echo Python was not found. Install Python 3.10+ from python.org, then run this again. >> logs\launcher.log
  pause
  exit /b 1
)

if not exist .venv (
  echo Creating virtual environment... >> logs\launcher.log
  python -m venv .venv >> logs\launcher.log 2>&1
  if errorlevel 1 goto fail
)

call .venv\Scripts\activate.bat

echo Installing/updating required packages... >> logs\launcher.log
python -m pip install --upgrade pip >> logs\launcher.log 2>&1
python -m pip install -r requirements.txt >> logs\launcher.log 2>&1
if errorlevel 1 goto fail

echo Launching app... >> logs\launcher.log
python app.py >> logs\launcher.log 2>&1
if errorlevel 1 goto fail
exit /b 0

:fail
echo.
echo Something failed. Open logs\launcher.log and copy the last lines.
echo.
type logs\launcher.log
pause
exit /b 1

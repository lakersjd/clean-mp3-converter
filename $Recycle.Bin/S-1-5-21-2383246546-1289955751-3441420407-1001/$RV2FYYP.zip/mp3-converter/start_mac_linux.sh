#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs
export PYTHONUTF8=1
export OPEN_BROWSER=1
{
  echo "Starting MP3 Converter..."
  if ! command -v python3 >/dev/null 2>&1; then
    echo "Python 3 was not found. Install Python 3.10+ first."
    exit 1
  fi
  if [ ! -d .venv ]; then
    echo "Creating virtual environment..."
    python3 -m venv .venv
  fi
  source .venv/bin/activate
  echo "Installing/updating required packages..."
  python -m pip install --upgrade pip
  python -m pip install -r requirements.txt
  echo "Launching app..."
  python app.py
} 2>&1 | tee logs/launcher.log
